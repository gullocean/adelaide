<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Server Path</title>
</head>

<body>
<?php
  echo getcwd();
?>
</body>
</html>
